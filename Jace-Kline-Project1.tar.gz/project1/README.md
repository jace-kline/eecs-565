# Instructions for Compilation/Execution

## Input/Output Vigenere Program
1. Navigate to vigenereIO directory
2. Run the Makefile with `make`
3. Run the program with `./prog`

## Vigenere Crack Program
1. Run the makefile in this directory with `make`
2. Run the program with input format as follows: `./prog <ciphertext> <key_length> <first_word_length>`
